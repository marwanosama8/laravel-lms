<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTeacherTable extends Migration {

	public function up()
	{
		Schema::create('teacher', function(Blueprint $table) {
			$table->increments('id');
			$table->timestamps();
			$table->string('name');
			$table->string('phone');
			$table->string('email');
			$table->datetime('member_at');
			$table->mediumInteger('age');
		});
	}

	public function down()
	{
		Schema::drop('teacher');
	}
}